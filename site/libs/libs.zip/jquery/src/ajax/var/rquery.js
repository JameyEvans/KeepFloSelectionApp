define( function() {
	return ( /\?/ );
} );
