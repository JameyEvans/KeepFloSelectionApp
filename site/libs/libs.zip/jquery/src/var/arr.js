define( function() {
	return [];
} );
